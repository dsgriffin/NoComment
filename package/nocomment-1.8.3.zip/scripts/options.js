'use strict';

// SET jQuery UI options display
$('#radio').buttonset();
$('#visualDisplay').selectmenu({ 'width': 'auto' });

$('#saveSettings, #saveAllowList, #saveBlockList').button({ icons: { 'primary': 'ui-icon-locked' } }).css('width', '240px');

$('[data-list="addNew"]').button({ icons: { 'primary': 'ui-icon-plus' } });
$('[data-list="modifySelected"]').button({ icons: { 'primary': 'ui-icon-gear' } });
$('[data-list="removeSelected"]').button({ icons: { 'primary': 'ui-icon-minus' } });
$('[data-list="removeAll"]').button({ icons: { 'primary': 'ui-icon-close' } });

// SET Allow List and Block List DataTables initialisation/customization.
$('#allowlist, #blocklist').DataTable({ 'scrollY': '200px', 'paging': false, 'jQueryUI': true });

$('div.accordion').accordion({ heightStyle: 'content', collapsible: false });

chrome.storage.sync.get({
  'settings': {
    'blockComments': true,
    'visualDisplay': 'collapse'
  },
  'allowlist': [],
  'blocklist': []
}, function (optionsStorage) {
  // SET: Data of both lists + options panel settings.
  var allowlist = $('#allowlist').DataTable();
  var blocklist = $('#blocklist').DataTable();

  var _iteratorNormalCompletion = true;
  var _didIteratorError = false;
  var _iteratorError = undefined;

  try {
    for (var _iterator = optionsStorage.allowlist.keys()[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
      var i = _step.value;
      allowlist.row.add(optionsStorage.allowlist[i]);
    }
  } catch (err) {
    _didIteratorError = true;
    _iteratorError = err;
  } finally {
    try {
      if (!_iteratorNormalCompletion && _iterator['return']) {
        _iterator['return']();
      }
    } finally {
      if (_didIteratorError) {
        throw _iteratorError;
      }
    }
  }

  var _iteratorNormalCompletion2 = true;
  var _didIteratorError2 = false;
  var _iteratorError2 = undefined;

  try {
    for (var _iterator2 = optionsStorage.blocklist.keys()[Symbol.iterator](), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
      var i = _step2.value;
      blocklist.row.add(optionsStorage.blocklist[i]);
    }
  } catch (err) {
    _didIteratorError2 = true;
    _iteratorError2 = err;
  } finally {
    try {
      if (!_iteratorNormalCompletion2 && _iterator2['return']) {
        _iterator2['return']();
      }
    } finally {
      if (_didIteratorError2) {
        throw _iteratorError2;
      }
    }
  }

  allowlist.draw();
  blocklist.draw();

  $('#radio1').prop('checked', optionsStorage.settings.blockComments).button('refresh');
  $('#radio2').prop('checked', !optionsStorage.settings.blockComments).button('refresh');
  $('#visualDisplay').val(optionsStorage.settings.visualDisplay).selectmenu('refresh');
});

// GET user-related extension storage preferences.
// Add vertical tabs class.
chrome.storage.local.get('currentTabIndex', function (obj) {
  $('#tabs').tabs({
    active: obj.currentTabIndex,
    activate: function activate(event, ui) {
      $('#allowlist').DataTable().columns.adjust();
      $('#blocklist').DataTable().columns.adjust();
      chrome.storage.local.set({ 'currentTabIndex': ui.newPanel[0].dataset.tabIndex });
    }
  }).addClass('ui-tabs-vertical ui-helper-clearfix');
});

// When a row is selected, adjust option buttons as appropriate.
$('#allowlist tbody, #blocklist tbody').on('click', 'tr', function () {
  $(this).toggleClass('selected');
  $('[data-list="modifySelected"][data-list-type=' + $(this).closest('table').attr('id') + ']').button('option', 'disabled', $(this).closest('table').find('.selected').length !== 1);
  $('[data-list="removeSelected"][data-list-type=' + $(this).closest('table').attr('id') + ']').button('option', 'disabled', $(this).closest('table').find('.selected').length < 1);
});

// SET: When the user saves their general settings, send these settings off to storage for later retrieval.
$('#saveSettings').click(function () {
  var _this = this;

  var settings = {
    'blockComments': $('#radio1').prop('checked'),
    'visualDisplay': $('#visualDisplay').val()
  };

  chrome.storage.sync.set({ 'settings': settings }, function () {
    // Update status to let user know options were saved.
    $(_this).next('h5.notification-alert').text('Your settings has been saved successfully.');
    $(_this).next('h5.notification-alert').slideDown(1000).delay(4000).slideUp(1000, function () {
      $(_this).next('h5.notification-alert').text('');
    });
  });
});

// SET: When the user saves their Allow List, send these settings off to storage for later retrieval.
$('#saveAllowList').click(function () {
  var _this2 = this;

  var allowlist = [];

  $('#allowlist').DataTable().rows().data().each(function (value, index) {
    allowlist[index] = value;
  });

  chrome.storage.sync.set({ 'allowlist': allowlist }, function () {
    $(_this2).next('h5.notification-alert').text('Your Allow List has been saved successfully.');
    $(_this2).next('h5.notification-alert').slideDown(1000).delay(4000).slideUp(1000, function () {
      $(_this2).next('h5.notification-alert').text('');
    });
  });
});

// SET: When the user saves their Block List, send these settings off to storage for later retrieval.
$('#saveBlockList').click(function () {
  var _this3 = this;

  var blocklist = [];

  $('#blocklist').DataTable().rows().data().each(function (value, index) {
    blocklist[index] = value;
  });

  chrome.storage.sync.set({ 'blocklist': blocklist }, function () {
    $(_this3).next('h5.notification-alert').text('Your Block List has been saved successfully.');
    $(_this3).next('h5.notification-alert').slideDown(1000).delay(4000).slideUp(1000, function () {
      $(_this3).next('h5.notification-alert').text('');
    });
  });
});

// SET: When the user saves a new list entry, process this.
$('[data-list="addNew"]').click(function () {
  var listType = $(this).data('listType') === 'allowlist' ? 'Allow List' : 'Block List';

  $('<div></div>').append('<p>Enter a valid URL/URL pattern:</p>\n             <input type="url" id="newListItem" class="ui-corner-all" style="width:240px;" placeholder="http://www.example.com"/>').dialog({
    modal: true,
    title: 'Add new URL/URL pattern to ' + listType,
    maxWidth: 'auto',
    buttons: [{
      text: 'Add New',
      icons: { primary: 'ui-icon-circle-check' },
      click: function click() {
        $('#' + listType.replace(/\s/g, '').toLowerCase()).DataTable().row.add([$('#newListItem').val()]).draw();
        $(this).dialog('destroy');
      }
    }, {
      text: 'Cancel',
      icons: { primary: 'ui-icon-closethick' },
      click: function click() {
        $(this).dialog('destroy');
      }
    }]
  });
});

// SET: When the user modifies a list entry, process this.
$('[data-list="modifySelected"]').click(function () {
  var listType = $(this).data('listType') === 'allowlist' ? 'Allow List' : 'Block List';

  var selectedRow = $('#' + listType.replace(/\s/g, '').toLowerCase()).DataTable().row('tr.selected:first');

  $('<div></div>').append('<p>Current URL/URL pattern:</p>\n             <p>' + selectedRow.data()[0] + '</p>\n             <p>Please enter a new URL/URL pattern:</p>\n             <input type="url" id="modifiedItem" class="ui-corner-all" style="width:240px;" placeholder="http://www.example.com"/>').dialog({
    modal: true,
    title: 'Modify ' + listType + ' entry',
    buttons: [{
      text: 'Confirm Changes',
      icons: { primary: 'ui-icon-circle-check' },
      click: function click() {
        selectedRow.data([$('#modifiedItem').val()]);
        $(this).dialog('destroy');
      }
    }, {
      text: 'Cancel',
      icons: { primary: 'ui-icon-closethick' },
      click: function click() {
        $(this).dialog('destroy');
      }
    }]
  });
});

// SET: When the user deletes a list entry/entries, process this.
$('[data-list="removeSelected"]').click(function () {
  var listType = $(this).data('listType') === 'allowlist' ? 'Allow List' : 'Block List';

  var selectedRows = $('#' + listType.replace(/\s/g, '').toLowerCase()).DataTable().rows('tr.selected');

  $('<div></div>').append('<p>Are you sure you want to remove the selected ' + listType + ' entry/entries?</p>').dialog({
    modal: true,
    title: 'Remove ' + listType + ' entry',
    buttons: [{
      text: 'Remove',
      icons: { primary: 'ui-icon-alert' },
      click: function click() {
        selectedRows.remove().draw();
        $(this).dialog('destroy');
      }
    }, {
      text: 'Cancel',
      icons: { primary: 'ui-icon-closethick' },
      click: function click() {
        $(this).dialog('destroy');
      }
    }]
  });
});

// SET: When the user removes all list entries, process this.
$('[data-list="removeAll"]').click(function () {
  var listType = $(this).data('listType') === 'allowlist' ? 'Allow List' : 'Block List';

  var allRows = $('#' + listType.replace(/\s/g, '').toLowerCase()).DataTable().rows();

  $('<div></div>').append('<p>Are you sure you want to remove all entries in the ' + listType + '?</p>').dialog({
    modal: true,
    title: 'Remove all ' + listType + ' entries',
    buttons: [{
      text: 'Remove All',
      icons: { primary: 'ui-icon-alert' },
      click: function click() {
        allRows.clear().draw();
        $(this).dialog('destroy');
      }
    }, {
      text: 'Cancel',
      icons: { primary: 'ui-icon-closethick' },
      click: function click() {
        $(this).dialog('destroy');
      }
    }]
  });
});
