'use strict';

chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  // The selector array - this can be expanded to target comments/comment sections on as many sites as possible.
  var selectorArray = ['body [id*="comment"]', 'body [class*="comment"]', '#disqus_thread', '[class*="replies-to"]'];
  // Main noComment object - contains User Settings, comment hide/show methods, URL parsing and more.
  var noComment = {
    'userSettings': {
      'blockAllComments': request.settings.blockComments,
      'display': request.settings.visualDisplay
    },
    'userLists': {
      'allowlist': request.allowlist,
      'blocklist': request.blocklist
    },
    'allComments': {
      'comments': document.querySelectorAll(selectorArray.join()),
      'hideAll': function hideAll() {
        var _iteratorNormalCompletion = true;
        var _didIteratorError = false;
        var _iteratorError = undefined;

        try {
          for (var _iterator = Array.from(noComment.allComments.comments).keys()[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
            var i = _step.value;

            if (noComment.userSettings.display === 'collapse') {
              noComment.allComments.comments[i].style.display = 'none';
            } else if (noComment.userSettings.display === 'hidden') {
              noComment.allComments.comments[i].style.visibility = 'hidden';
            }
          }
        } catch (err) {
          _didIteratorError = true;
          _iteratorError = err;
        } finally {
          try {
            if (!_iteratorNormalCompletion && _iterator['return']) {
              _iterator['return']();
            }
          } finally {
            if (_didIteratorError) {
              throw _iteratorError;
            }
          }
        }
      }
    },
    'isNotInAllowList': function isNotInAllowList() {
      var allowlist = noComment.userLists.allowlist;
      var currentURL = document.location.href;

      var _iteratorNormalCompletion2 = true;
      var _didIteratorError2 = false;
      var _iteratorError2 = undefined;

      try {
        for (var _iterator2 = allowlist.keys()[Symbol.iterator](), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
          var i = _step2.value;

          var structuredURL = noComment.urlHandling.checkProtocol(allowlist[i].toString());
          var regexURL = new RegExp(structuredURL.replace(/\./g, '\\.').replace(/\*/g, '.+') + '/?$');

          if (regexURL.test(currentURL)) {
            return false;
          }
        }
      } catch (err) {
        _didIteratorError2 = true;
        _iteratorError2 = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion2 && _iterator2['return']) {
            _iterator2['return']();
          }
        } finally {
          if (_didIteratorError2) {
            throw _iteratorError2;
          }
        }
      }

      return true;
    },
    'isInBlockList': function isInBlockList() {
      var blocklist = noComment.userLists.blocklist;
      var currentURL = document.location.href;

      var _iteratorNormalCompletion3 = true;
      var _didIteratorError3 = false;
      var _iteratorError3 = undefined;

      try {
        for (var _iterator3 = blocklist.keys()[Symbol.iterator](), _step3; !(_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done); _iteratorNormalCompletion3 = true) {
          var i = _step3.value;

          var structuredURL = noComment.urlHandling.checkProtocol(blocklist[i].toString());
          var regexURL = new RegExp(structuredURL.replace(/\./g, '\\.').replace(/\*/g, '.+') + '/?$');

          if (regexURL.test(currentURL)) {
            return true;
          }
        }
      } catch (err) {
        _didIteratorError3 = true;
        _iteratorError3 = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion3 && _iterator3['return']) {
            _iterator3['return']();
          }
        } finally {
          if (_didIteratorError3) {
            throw _iteratorError3;
          }
        }
      }

      return false;
    },
    'urlHandling': {
      'checkProtocol': function checkProtocol(urlString) {
        if (urlString.search(/^http[s]?\:\/\//) === -1) {
          urlString = '*://' + urlString;
        }

        return urlString;
      }
    },
    'observeChanges': {
      'mutations': new window.MutationObserver(function () {
        var matches = document.querySelectorAll(selectorArray.join());

        var _iteratorNormalCompletion4 = true;
        var _didIteratorError4 = false;
        var _iteratorError4 = undefined;

        try {
          for (var _iterator4 = Array.from(matches).keys()[Symbol.iterator](), _step4; !(_iteratorNormalCompletion4 = (_step4 = _iterator4.next()).done); _iteratorNormalCompletion4 = true) {
            var i = _step4.value;

            if (matches[i].style.display !== 'none') {
              if (noComment.userSettings.display === 'collapse') {
                matches[i].style.display = 'none';
              } else if (noComment.userSettings.display === 'hidden') {
                matches[i].style.visibility = 'hidden';
              }
            }
          }
        } catch (err) {
          _didIteratorError4 = true;
          _iteratorError4 = err;
        } finally {
          try {
            if (!_iteratorNormalCompletion4 && _iterator4['return']) {
              _iterator4['return']();
            }
          } finally {
            if (_didIteratorError4) {
              throw _iteratorError4;
            }
          }
        }
      }),
      'config': {
        attributes: true,
        childList: true,
        characterData: true,
        subtree: true,
        attributeFilter: ['id', 'class']
      }
    },
    'blockableContent': false
  };

  if (noComment.userSettings.blockAllComments) {
    // If all comments are set to be blocked by default,
    // Check whether the current URL is in Allow List and take appropriate action.
    if (noComment.isNotInAllowList()) {
      // It is necessary to show page action.
      noComment.blockableContent = true;
      // Observe any additional elements that match selectorArray
      noComment.observeChanges.mutations.observe(document.body, noComment.observeChanges.config);
      // This URL/URL pattern is not Allow List - loop through all comments on page and hide (depending on user visual setting).
      noComment.allComments.hideAll();
    }
  } else {
    if (noComment.isInBlockList()) {
      // It is necessary to show page action.
      noComment.blockableContent = true;
      // Observe any additional elements that match selectorArray
      noComment.observeChanges.mutations.observe(document.body, noComment.observeChanges.config);
      // Current URL is in Block List - hide all comments.
      noComment.allComments.hideAll();
    }
  }
  // Need to include whether or not the current page contains blockable content, so that the page action can be displayed.
  sendResponse({ 'blockableContent': noComment.blockableContent, 'commentsLength': noComment.allComments.comments.length });
});
